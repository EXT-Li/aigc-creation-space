# Ecommerce Detail Page Patterns

This reference contains reusable structures for the **电商详情页Skill**. Adapt patterns to the product, buyer, evidence, and requested platform. They are not a reason to invent facts or force every product into the same eight screens.

## Default eight-screen flow

1. **Identity and desire** — product name, category, hero product view, two to four core claim seeds, and an honest CTA.
2. **Pain or choice** — the buyer's problem, common compromise, or decision criterion. Use comparison only when the alternative is known and fair.
3. **Core benefit** — show the strongest benefit in a believable use moment. Pair outcome language with the feature or evidence that supports it.
4. **Feature evidence** — use macro crops, material callouts, ingredient notes, construction diagrams, dimensions, controls, or process steps.
5. **Scenario fit** — show three to five realistic occasions, users, rooms, pairings, or workflows. Captions should identify what changes in each scene.
6. **Trust and proof** — use confirmed reviews, testing, process transparency, warranty, certification, after-sales policy, or explicit limits. Unknown proof becomes a placeholder or is omitted.
7. **Choice and value** — compare variants, sizes, bundles, included accessories, compatibility, or value. Keep rows scannable and factual.
8. **Conversion and after-sales** — summarize the reason to buy, shipping/returns, guarantee, honest offer details, and final CTA.

## Category adaptations

### Food and beverage

Useful evidence: visible ingredients, texture, preparation, serving temperature, pairing, portion or package information, storage, and sharing occasions.

Avoid: unverified nutrition numbers, health effects, “zero additive” language, origin claims, shelf life, or certifications unless supplied.

### Cosmetics and personal care

Useful evidence: texture, application steps, ingredient story, skin-feel, routine placement, packaging, usage amount, and suitable audience.

Avoid: medical treatment, absolute safety, guaranteed outcomes, before/after claims, or sensitive-person guarantees without confirmed evidence and appropriate review.

### Apparel, shoes, and accessories

Useful evidence: silhouette, fabric or material, construction, fit, size guidance, detail crops, styling, movement, care, and occasion.

Avoid: exact fit promises without a size basis, unsupported material percentages, durability guarantees, or model identity that the user did not authorize.

### Home, furniture, and appliances

Useful evidence: scale in a room, installation, controls, storage, material, load or capacity, maintenance, noise or energy claims when confirmed, and after-sales.

Avoid: invented dimensions, load ratings, energy grades, safety certifications, or compatibility claims.

### Digital products, plugins, and services sold online

Useful evidence: actual interface, before/after workflow, supported formats, limits, integrations, pricing context, setup steps, and permission boundaries.

Avoid: generic “can do everything” promises, unsupported model performance, or hiding quotas and requirements.

## Copy structure patterns

Use different patterns for different buyer questions. The pattern controls sentence rhythm and visible text modules; renaming a repeated headline/body/tag layout is not enough.

- `hero_claim_stack`: product identity + concise promise + CTA.
- `question_answer`: a buyer question followed by a specific answer and one proof cue.
- `single_line_with_labels`: one compact claim with labels for material, use, or audience.
- `annotation_map`: product macro with arrows, labels, and short explanations.
- `three_point_breakdown`: one feature or benefit supported by three distinct details.
- `mini_steps`: a short preparation, setup, use, or care sequence.
- `scene_caption_cluster`: one lifestyle composition with several captions anchored to real use moments.
- `trust_checklist`: compact proof, process, warranty, limit, or after-sales notes.
- `comparison_rows`: factual variant or alternative comparison with a clear choice cue.
- `quiet_closing`: small reassurance, offer summary, and CTA with generous negative space.

## Composition shifts

Use composition changes to keep a long page from becoming eight posters:

- Full-bleed product identity for the opener.
- Partial product crop or diagonal flow for pain/choice.
- In-use scene for the core benefit.
- Macro crop with annotation lines for feature evidence.
- Multi-scene or modular caption cluster for scenarios.
- Quiet, compact proof layout for trust.
- Table, split view, or stacked variant cards for choice.
- Calm closing composition with clear conversion elements.

Keep the same product rendering, palette, light direction, typography system, and recurring motifs. Change zoom, information density, camera relationship, and module placement rather than changing the entire art direction.

## Platform adaptation matrix

Start from one factual and visual master, then adapt the output layer:

| Output target | Preserve | Adapt | Typical review focus |
|---|---|---|---|
| Marketplace long image | product identity, claim meaning, proof | slice ratio, safe areas, text density, CTA placement | scrolling rhythm and legibility |
| Mobile storefront | product story, evidence, variant logic | vertical spacing, sticky CTA, touch targets, image crop | first viewport and tap clarity |
| Desktop storefront | product story, evidence, comparison | wider layout, grids, side-by-side modules, sticky purchase panel | scan path and responsive states |
| Social-commerce landing | product, occasion, trust, CTA | shorter copy, faster hook, platform-safe crop | first-screen comprehension |
| Print or offline catalog | factual copy, product visuals, contact/offer | physical dimensions, bleed, color profile, QR/contact area | print readability and versioning |

Do not fill in exact platform dimensions from memory when they materially affect delivery. Use user-supplied specifications or verify the current official platform guidance when exact compliance is required.

## Blueprint sanity checks

Before approval one:

- Screen 01 has two to four claim seeds that can support later screens.
- Every later screen names the seed it expands.
- Adjacent screens answer different buyer questions.
- At least 70% of screens have one primary module and one to three useful secondary modules unless sparseness is intentional.
- Copy structures and composition shifts vary across the page.
- Proof is clearly marked as confirmed, inferred, placeholder, or unavailable.
- The CTA matches the actual user goal: buy, choose a variant, add to cart, request a quote, book, subscribe, or contact support.

## Long-scroll continuity checks

For a `1:3` master and `9:21` slices:

- The background world, light direction, material language, product identity, and recurring motifs remain stable.
- The top edge carries material from the previous screen and the bottom edge introduces material for the next.
- Edge zones do not contain the most important headline, price, proof, or CTA.
- Later screens do not restart with the same full product-plus-model hero.
- The page varies between scene, macro, annotation, captions, proof, comparison, and closing modules.
- The concatenated preview reads as one long ecommerce page rather than unrelated social posters.

## Trust and compliance checklist

Flag or remove:

- fabricated certifications, awards, test results, review counts, or rankings;
- medical, health, safety, or environmental claims without evidence;
- exact discounts, urgency, inventory, delivery times, or guarantees that were not supplied;
- competitor comparisons that lack a known basis;
- altered product colors, dimensions, components, logos, or package contents;
- text that is unreadable, misspelled, or rendered as meaningless glyphs.

## Revision routing quick reference

| Failure | Smallest responsible revision |
|---|---|
| headline or label wrong | revise `text_exact` for that screen |
| product changed | strengthen product reference and regenerate affected screen |
| one screen too dense | revise modules, density, hierarchy, or crop |
| two screens do not connect | revise their edge anchors and neighboring slice |
| many screens look identical | revise composition shifts and copy patterns |
| whole page feels inconsistent | revise text/visual master, then dependent slices |
| story does not persuade | return to the blueprint and claim seeds |
| one platform crops badly | revise only that platform's output layer |
