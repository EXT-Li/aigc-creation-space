---
name: 电商详情页Skill
description: "规划、撰写、设计、生成、实现和审核跨平台电商商品详情页、商品长图、商品视觉素材与响应式商品页面。当用户提供商品、商品图、参考图、商品资料、截图或现有店铺页面，并需要详情页结构、卖点文案、视觉提示词、长图切片、页面改版或截图质检时使用。不用于没有购买决策的通用品牌落地页或非电商内容。"
metadata:
  short-description: "跨平台电商详情页规划、生成、优化与审核"
---

# 电商详情页 Skill

## Purpose

Use this skill to turn a product and its evidence into a clear, persuasive, platform-adaptable ecommerce detail page. The output may be a page blueprint, conversion copy, image-generation prompts, a long-scroll image set, a responsive frontend page, a review report, or a combination explicitly requested by the user.

The skill name, folder name, package name, and user-facing name are all **电商详情页Skill**.

Prioritize product comprehension and purchase confidence over decorative novelty. Every visual, claim, module, and CTA should help the buyer answer a real question: what is it, why do I need it, why should I believe it, how do I use or choose it, and what happens after I buy it?

## Scope and mode routing

Use the narrowest mode that completes the request:

- **Planning mode:** create a buyer-decision-based detail-page architecture, usually eight screens, with selling-point seeds, copy modules, visual direction, and risk notes.
- **Copy mode:** write or refine product titles, selling points, section copy, labels, comparisons, FAQs, CTA text, and platform variants while separating confirmed facts from proposed wording.
- **Image mode:** convert a confirmed blueprint and product/reference images into a continuous long-scroll visual system, staged image prompts, slices, previews, and an audit.
- **Frontend mode:** implement or redesign a responsive ecommerce detail page only when the user asks for code or a page implementation. Inspect the existing project before editing.
- **Review mode:** inspect an existing page, screenshot, long image, or prompt for clarity, conversion logic, product consistency, platform fit, unsupported claims, and responsive/layout defects.

Do not silently expand a copy request into image generation, a visual request into a website, or a page review into unrelated branding, automation, video, or presentation work. Ask before adding a materially different deliverable.

## Execution contract

For image-led ecommerce detail-page requests, follow this route unless the user explicitly asks to skip a stage:

1. Analyze the product inputs, reference style, buyer, platform targets, confirmed facts, and unknowns.
2. Produce the complete page blueprint and stop for approval one.
3. After approval, lock the text master, visual style DNA, structure, and platform adaptation rules.
4. When a continuous visual reference is useful, generate and inspect a `1:3` long-page master.
5. Generate and inspect the first two final slices, then create and inspect their concatenated preview.
6. Present the master, both slices, the two-slice preview, and a concise audit; stop for approval two.
7. Generate the remaining slices only after approval two.
8. Concatenate and inspect the full page, run the final audit, preserve accepted files, and report the delivery folder.

The standard workflow has exactly two normal approval gates. Silence is not approval. A generic request to “continue” does not approve an unreviewed blueprint or visual sample package. Add another confirmation only when a serious failure blocks safe continuation or the user requests a workflow change.

Use the user's product images, reference images, confirmed facts, approved blueprint, and approved masters as authoritative inputs. Preserve accepted outputs; save revisions as new versions rather than overwriting them.

If a required image-generation, editing, browser, or rendering capability is unavailable, state the limitation, preserve the current stage, and offer the smallest relevant alternative. Do not create fake images, placeholder deliverables, or code that pretends to have generated media.

## Input audit

Before planning, identify:

- Product name, category, variant, audience, buying occasion, and intended marketplace or storefront.
- Observed product facts: shape, color, material, packaging, components, interface, ingredients, visible marks, and usage clues.
- Confirmed commercial facts: specifications, price/offer, certification, warranty, delivery/returns, reviews, measured performance, and prohibited claims.
- Candidate selling points inferred from the evidence. Mark these as **AI-inferred** until the user confirms them.
- Buyer objections and decision questions: fit, size, taste/texture, durability, compatibility, safety, maintenance, value, authenticity, delivery, and after-sales issues as relevant to the category.
- Desired output: copy, blueprint, marketplace long image, separate slices, one long image, responsive page, prompts, review, or a platform variant matrix.
- Platform requirements: target channels, ratio, pixel size, safe areas, text limits, CTA conventions, and whether exact current specifications must be verified.

When confirmed selling points or specifications are missing, give the user one concise opportunity to provide them. Do not turn this into a mandatory questionnaire. If the user declines, proceed with category-level inference and label unconfirmed claims for review before commercial use.

Analyze a reference image as style DNA, not as a source to copy. Abstractly preserve useful traits such as lighting, camera angle, material treatment, model or mascot role, hand-held reveal, macro annotation language, composition rhythm, or typography mood. Do not copy another brand's logo, exact text, identifiable person, product, or distinctive campaign composition.

## Cross-platform system

Build one content source of truth and adapt its presentation for each channel. Do not write contradictory claims for different platforms.

Maintain these layers separately:

1. **Fact layer:** product facts, approved proof, limits, disclaimers, and unavailable information.
2. **Message layer:** claim seeds, buyer questions, exact copy, proof angle, CTA intent, and objection handling.
3. **Design layer:** visual world, layout, typography, product framing, recurring motifs, and hierarchy.
4. **Output layer:** platform ratio, dimensions, safe zones, text density, file format, and slice/long-image packaging.

If several platforms are requested, first create a platform-neutral master. Then produce a small adaptation matrix for each target, changing only layout density, crop, CTA wording, safe zones, and technical output requirements. Keep the product identity, fact layer, claim meaning, and visual DNA stable.

Use a requested platform's exact pixel, character, or compliance rules only when the user supplies them or they have been checked against a current authoritative source. Otherwise describe the output as platform-adaptable and leave exact values configurable. A default visual slice may use `9:21`, but the user can request `3:4`, `4:5`, `1:1`, desktop web, mobile web, or another ratio.

## Page blueprint

For an image-led long detail page, output the blueprint before generating final images. Default to eight sequential screens, but change the count only when the user requests another count or the product needs a clearly different narrative.

The default buyer-decision sequence is:

1. **Identity and desire:** what the product is, who it is for, the core promise, and a purchase-oriented CTA.
2. **Pain or choice:** the problem, common workaround, or choice criterion the buyer is struggling with.
3. **Core benefit:** the strongest functional or emotional result shown in use.
4. **Feature evidence:** material, structure, ingredient, technology, controls, dimensions, or craft details.
5. **Scenario fit:** realistic use moments, audiences, pairings, or occasions.
6. **Trust and proof:** reviews, test evidence, warranty, process, certification, or transparent limits when confirmed.
7. **Choice and value:** variants, sizes, bundle contents, comparison, compatibility, or value stack.
8. **Conversion and after-sales:** offer summary, shipping/returns, guarantee, urgency only when honest, and final CTA.

Define the screen-01 `claim_seed` set before writing later screens. Use two to four concrete seeds that can be proved visually, such as a visible ingredient/detail, a texture or performance promise, a usage moment, a convenience cue, a trust signal, or an emotional buying occasion. Each later screen must expand, prove, visualize, compare, or contextualize one of those seeds. Do not introduce an unrelated selling point late in the page without revising the approved blueprint.

Each screen must include these planning fields:

`slice_id`, `buyer_question`, `module_type`, `module_label`, `claim_seed`, `screen_job`, `evidence_type`, `content_density`, `layout_archetype`, `copy_module_type`, `copy_structure_pattern`, `primary_module`, `secondary_modules`, `text_exact`, `hierarchy_strategy`, `composition_shift`, `top_edge_anchor`, `bottom_edge_anchor`, `visual_composition`, `reference_style_notes`, and `risk_unknowns`.

For multi-platform work, add `platform_variants` and `output_constraints` when they materially affect the screen. For copy-only work, keep the same logic but omit fields that do not help the requested deliverable.

Treat planning fields as internal controls. Never expose labels such as `module_type`, `screen_job`, `parameter_trust`, `FAQ`, or `claim_seed` as visible consumer copy. Convert them into natural Chinese or the user's requested language.

At least 70% of screens should carry two to four meaningful content points through one primary module plus one to three secondary modules, unless the user explicitly requests a sparse editorial page. Vary copy structures: hero claim stack, question-answer, single line with labels, annotation map, three-point breakdown, scene-caption cluster, mini steps, comparison rows, trust checklist, and quiet closing. If three or more screens share the same headline-plus-body-plus-tags rhythm, rewrite the copy structures and composition shifts before generation.

Before requesting approval one, audit three things:

- Every screen answers a different buyer question.
- Every later screen traces back to the first-screen claim seeds.
- Adjacent screens differ in copy role, evidence type, information density, and composition rather than merely changing adjectives.

## Text and claim discipline

- Put the product name, category, and primary CTA where the buyer can find them immediately.
- Prefer concrete, recognizable language over empty adjectives such as “顶级”, “极致”, “全网第一”, or “黑科技”.
- Do not invent exact parameters, certification, awards, sales volume, review counts, medical effects, safety guarantees, discounts, scarcity, celebrity endorsements, or brand partnerships.
- When facts are unknown, use a neutral formulation, an explicit placeholder such as `[待确认]`, or a question for the user. Do not hide uncertainty inside confident marketing copy.
- Keep a claim's strength proportional to its evidence. A visual impression is not a measured result; a product feature is not automatically a user outcome.
- Separate headline promise, explanation, proof, limitation, and CTA. Body copy should add evidence or context rather than repeat the headline.
- For regulated, health, food, cosmetics, children, finance, or safety-related products, flag claims that may require legal or platform review. Do not present a creative inference as compliance-approved copy.
- Keep the selected language, terminology, units, and currency consistent across all platform variants.

## Visual master and image production

Create a text master before image generation. It should lock:

- `visual_master_spec`: palette, lighting, space, materials, typography, product identity, recurring motifs, section rhythm, and platform-safe text areas.
- `master_reference_prompt`: the shared description of the continuous visual world and product-rendering rules.
- `visual_style_dna`: the small set of abstract style decisions that must persist across every output.
- Ordered structure blueprint: screen jobs, claim seeds, evidence types, copy hierarchy, composition shifts, and edge anchors.

When useful, generate a `1:3` continuous spatial master to stabilize the long page. Inspect it before proceeding. It should read as one ecommerce page system with a coherent background world, light direction, product scale rhythm, transition logic, and reserved or simplified text hierarchy. It is a reference, not the final deliverable and not a crop source. Do not copy it pixel-for-pixel into final slices.

Final slices should normally be separate vertical page sections, preferably `9:21` unless the user specifies another ratio. Every slice must follow the approved screen structure exactly. When a spatial master exists, inherit its world, lighting, materials, recurring motifs, product identity, and edge continuity while expanding the current screen's own information task. Make each slice feel like one region of a long detail page, not an independent social poster.

For text-heavy Chinese layouts, inspect the actual rendered text. If the chosen image tool cannot reliably render Chinese, use reserved text zones and a suitable compositing/layout step when available, or clearly mark the result as a visual reference rather than a final commercial asset. Never claim that garbled or missing text is ready for publishing.

Keep the product stable across every image: color, shape, proportions, logo, material, package window, handles, ports, buttons, ingredient appearance, and included accessories. Use the user's product reference as the identity anchor; do not replace it with a generic category object.

## Staged approvals and continuity audit

After the first two final slices:

- Concatenate a lightweight two-slice preview.
- Inspect both individual slices and the concatenated preview.
- Check that the opener establishes the product and the second screen continues its world without repeating the same poster composition.
- Present the `1:3` master when used, both slices, the preview, and a concise audit as one sample package.
- Stop for approval two before generating the remaining slices.

After the full set:

- Concatenate the slices in order and inspect the complete long-scroll rhythm.
- Check top/bottom carryover, background continuity, product identity, text quality, hierarchy, crop safety, and CTA visibility.
- Fail the set if every slice restarts with a centered hero, repeats identical title/tag blocks, repeats the same product-plus-model composition, or lacks edge material that connects neighboring sections.
- Remove or quarantine rejected and superseded variants from the final delivery by default, while preserving accepted masters and source files.

## Frontend implementation mode

When the user asks for a coded detail page:

1. Inspect the repository structure, framework, routes, components, design tokens, asset strategy, and existing styling before editing.
2. Reuse existing components and utilities where they fit; edit the smallest reasonable set of files.
3. Make the product signal, price/variant state, proof, purchase action, delivery/returns, and relevant FAQ discoverable in the buyer's decision order.
4. Treat mobile as a first-class layout. Check image framing, sticky or repeated CTA behavior, touch targets, text overflow, and long-page performance.
5. Verify with a real render at a desktop and mobile viewport. Fix blank media, overlap, missing states, unreadable text, awkward crops, and layout shifts before handoff.
6. Report the local URL or absolute file path the user can open.

Do not implement a storefront, payment flow, order system, or backend unless the user explicitly requests it.

## Revision routing

Route a failure to the smallest responsible layer:

- **Copy or wording:** revise `text_exact` and regenerate or repair only the affected screen.
- **Unsupported claim:** remove or qualify the claim; do not solve it with visual polish.
- **Product drift:** strengthen the product-reference constraint and regenerate only affected outputs.
- **Single-screen hierarchy or clutter:** revise its modules, density, copy pattern, hierarchy, or crop.
- **Adjacent transition:** revise the two edge anchors and the smallest neighboring slice range.
- **Repeated visual grammar:** revise `composition_shift` for the repeated screens while keeping the approved narrative.
- **Whole-page style or spatial continuity:** revise the text master or spatial master, then regenerate dependent slices when possible.
- **Narrative or claim-seed failure:** return to the blueprint; use full regeneration only when the approved story changes substantially.
- **Platform adaptation issue:** change the output layer or layout variant; do not change facts or claim meaning.

Do not silently change the production route after a failed result. If a change affects an approved blueprint or master, request the appropriate confirmation again.

## Delivery

Use the user's requested destination when supplied. Otherwise create a clearly named folder under the active workspace. For image-led work, include the complete approved set when applicable:

- `product_master_1x3.*` when a master was used;
- sequential final slices such as `product_screen_01.*` through the requested count;
- the early two-slice preview;
- the full-resolution long-image concat;
- platform variants and a compact manifest when multiple platforms were requested.

Preserve original generated files and do not include rejected variants unless explicitly requested. Verify every requested file exists and report the absolute delivery folder or local URL.

## Review rubric

Score each area as `pass`, `needs work`, or `missing` and give a concrete fix:

- First-viewport product and category clarity
- Buyer-question sequence and claim-seed continuity
- Specific, evidence-backed selling points
- Product-revealing visual assets
- Copy and visual hierarchy
- Platform adaptability and safe-area fit
- Product identity consistency
- Text legibility and language consistency
- Responsive behavior when code is involved
- CTA and purchase-decision completeness
- Technical and regulatory honesty
- Existing design-system fit
- Early and final continuity previews

## Reference routing

Read [references/ecommerce-detail-page-patterns.md](references/ecommerce-detail-page-patterns.md) when choosing a section structure, adapting a page for multiple ecommerce platforms, selecting category-specific proof modules, or reviewing whether a long detail page is complete. Do not load it for a simple one-line copy edit unless the category or structure is ambiguous.
