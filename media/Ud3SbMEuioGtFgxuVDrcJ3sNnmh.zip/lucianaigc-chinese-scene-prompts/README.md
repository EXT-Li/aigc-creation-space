# LucianAIGC-中式场景提示词skill

这是一个中文优先、跨平台通用的中式场景提示词 skill，适用于中式建筑、园林、江南水乡、宫殿寺观、山水峡谷、雪景庭院、仙侠云阁和中式幻想空间。

## 特点

- 默认输出中文。
- 先建立主体、前中后景、动线和观看方式，再补光影、材质与氛围。
- 支持生成、扩写、改写、诊断、变体和多平台适配。
- 将 Midjourney 等平台参数与通用中文核心分离。
- 附带场景模块库、平台适配指南和中文使用教程。
- 不需要额外运行时、网络服务或第三方 API。

## 调用

显式调用名称：

`$lucianaigc-chinese-scene-prompts`

界面展示名称：

`LucianAIGC-中式场景提示词skill`

快速示例：

> 使用 $lucianaigc-chinese-scene-prompts，生成一座晨雾中的江南临水园林，输出中文通用核心提示词。

## 包内文件

- `SKILL.md`：Codex skill 主入口。
- `agents/openai.yaml`：界面名称、描述、默认调用语句和自动调用策略。
- `references/场景模块库.md`：建筑、地域、构图、季节、光影、材质和仙侠模块。
- `references/平台适配指南.md`：通用核心、Midjourney、Nano Banana、Stable Diffusion/Flux、OpenAI 图像工具和未知平台适配方法。
- `references/使用教程.md`：输入模板、调用示例、修改方式和排错指南。

## 目录说明

Codex 技术目录名为 `lucianaigc-chinese-scene-prompts`，这是为了符合 skill 目录命名规范；用户界面和教程中保留产品名称“LucianAIGC-中式场景提示词skill”。

详细教程请打开 `references/使用教程.md`。
