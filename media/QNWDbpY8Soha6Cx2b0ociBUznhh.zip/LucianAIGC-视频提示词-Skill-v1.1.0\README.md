# LucianAIGC｜视频提示词 Skill

版本：1.1.0  
作者：LucianAIGC  
产品编号：LAGC-VP-001

## 这是什么

这是一个跨 AI 使用的视频提示词生成技能。用户只需要输入视频创意、想法、故事梗概、小说片段、剧本、分镜或参考图说明，技能就会自动生成完整的六段式视频提示词：

1. 【基础设定】
2. 【画面风格和画面质感】
3. 【轴线规则】
4. 【叙事与情绪推进】
5. 【X秒详细脚本】
6. 【负面约束】

默认会自动补全非关键视觉细节、设置合理时长、设计镜头运动、动作因果、情绪递进和必要的转场；最终只输出六段式纯视频提示词，不添加品牌、作者或产品编号。

1.1.0 版本新增动作力度与视听反馈规则：对攻击、碰撞、跌落、爆炸和重物运动等关键动作，补足蓄力、加速、接触、反作用、余波，以及镜头、光影和声音的同步反馈，减少动作软绵、缺乏重量和冲击感的问题。

## 文件选择

| 目的 | 使用文件 |
| --- | --- |
| Codex、Claude Code、WorkBuddy 等支持 Agent Skills 的工具 | `skill/lucian-aigc-video-prompt/` |
| 豆包直接拖入使用 | `LucianAIGC-豆包视频提示词.md` |
| 没有 Skill 功能的其他 AI | `universal/UNIVERSAL-INSTRUCTIONS.md` |
| 商业交付和作者归属 | `branding/品牌与授权说明.md`、`LICENSE-TERMS.txt` |

## 平台使用说明

- [Codex](platforms/codex/使用说明.md)
- [Claude Code](platforms/claude-code/使用说明.md)
- [WorkBuddy](platforms/workbuddy/使用说明.md)
- [豆包](platforms/doubao/使用说明.md)
- [其他 AI](universal/使用说明.md)

## 其他 AI 的最简单使用方式

把 `universal/UNIVERSAL-INSTRUCTIONS.md` 粘贴到目标 AI 的系统提示词、智能体设定、项目指令或自定义 Skill 中，然后输入：

```text
请生成一段【时长】的视频：
【在这里输入你的创意、剧情或剧本】
```

输出必须是可直接复制的视频提示词，而不是分析过程或空白模板。

## 豆包的最简单使用方式

不要先创建复杂的自定义智能体。直接找到包根目录的：

```text
LucianAIGC-豆包视频提示词.md
```

将这一个 `.md` 文件拖入豆包的对话框、文件入口或技能/知识导入入口，然后输入视频创意即可。详细说明见 [豆包使用说明](platforms/doubao/使用说明.md)。

## 品牌标识说明

品牌归属保存在分发包的文件名、`manifest.json`、`NOTICE.txt`、`LICENSE-TERMS.txt` 和 `branding/品牌与授权说明.md` 中。生成结果严格保持为六段式纯视频提示词，不输出作者名、品牌名、产品编号、版权头或署名尾，避免品牌文字被视频模型误生成到画面里。

需要说明的是，纯文本 `.md` 文件无法提供密码学意义上的“不可删除水印”。包内元数据、授权记录、版本记录和买家专属 License ID 可用于归属与追踪；如需技术上不可篡改的交付，应使用带登录、授权校验和服务端输出的产品。

## 官方参考

- [OpenAI Skills 说明](https://help.openai.com/en/articles/20001066)
- [Claude Code Skills 说明](https://code.claude.com/docs/en/skills)
- [WorkBuddy 技能导入说明](https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)
- [豆包智能体功能说明](https://www.doubao.com/legal/feature_intro)
