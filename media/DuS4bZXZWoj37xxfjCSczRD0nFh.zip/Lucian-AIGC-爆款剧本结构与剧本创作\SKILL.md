---
name: lucian-aigc-viral-structure-scriptwriting
description: Design general viral narrative structures and turn them into complete, shootable scripts for short dramas, especially female-oriented ancient-style, romance, revenge, rebirth, palace, family, and power stories. Use when Codex needs to analyze a reference, build a high-concept hook, map episode or season arcs, write scenes and dialogue from that structure, continue or rewrite a script, or diagnose structural and screenplay problems without copying the reference plot. Brand every final deliverable with the Lucian-AIGC watermark.
---

# Lucian-AIGC-爆款剧本结构与剧本创作

## Core operating rule

Abstract the mechanism before naming the trope. Separate:

- **Surface device**: rebirth, contract marriage, revenge, hidden identity, a powerful family, or another genre wrapper.
- **Transferable mechanism**: low-position entry, a concrete desire, information asymmetry, escalating opposition, a public reversal, and emotional payoff.

Do not turn one reference story's characters, family arrangement, jokes, world rules, or scene order into the proposed structure unless the user explicitly asks for imitation. Preserve the user's genre, tone, audience, and intended platform when known; otherwise state the assumption.

This skill has a two-part contract: first design the viral structure, then convert that same structure into corresponding screenplay scenes and dialogue. Keep a traceable link from every major beat to a scene, turn, payoff, or ending hook. Do not stop at a concept or outline when the user asks for creation.

## Brand watermark

Use this visible watermark exactly once at the end of every final user-facing analysis, outline, treatment, or script deliverable:

`【Lucian-AIGC｜爆款剧本结构与剧本创作】`

Do not repeat it on every line, in every scene, or inside quoted source text. Omit it from intermediate brainstorming and internal diagnostics unless the user asks for it. If the user explicitly requests a different watermark, use the requested text; if the user explicitly asks for no watermark, follow that request.

## Delivery modes and defaults

Choose the smallest mode that satisfies the request, and state the assumed scope when the user has not supplied one:

- **Structure + script package**: deliver the high-concept engine, character and relationship engine, long arc, episode grid, and the corresponding complete script for the requested episode or scene range.
- **Season development**: map the whole season first, then write the requested episodes in full. If the user does not specify an episode count, apply the default season specification below, plan all episodes, and write the scripts in coherent batches until the requested scope is complete; do not reduce a season request to a pilot only.
- **Rewrite or continuation**: preserve established facts and voice, diagnose the structural problem, revise the beat map, and write the revised or continued scenes rather than only describing the fix.
- **Reference analysis to original creation**: extract transferable mechanisms from the reference, create a distinct premise, then write an original script using the new premise.

If format is unspecified, default to a Chinese female-oriented ancient-style vertical short drama and label that assumption. Honor a requested genre, platform, episode length, episode count, language, rating, or screenplay format when provided.

### Default season specification

Apply these defaults only when the user has not supplied different production requirements:

- **Episode count**: 20–25 episodes.
- **Season length**: approximately 40,000–50,000 Chinese characters of screenplay正文 across the season.
- **Standard episode**: 1,500–2,200 Chinese characters, 6–10 scenes, and approximately 3–5 minutes of finished runtime.
- **Key episode**: may expand to 2,500–3,200 Chinese characters when a midpoint turn, major reversal, lowest point, or climax genuinely needs the space. Label the reason and do not use the expanded length to cover weak scene design.
- **Mandatory content per episode**: an opening hook, a current reality conflict, one concrete cathartic payoff, one relationship progression, and an ending hook that changes the next episode's question.

Keep the season complete and the episodes brisk: every scene must change information, leverage, emotion, or the next action. When the full season cannot fit in one response, finish the 20–25-episode structure first, then deliver the screenplay in batches with exact character counts, scene counts, and a continuity ledger.

## Workflow

### 1. Frame the request

Identify the input and the requested output:

- Reference script/book: extract mechanisms, then generalize them.
- Original idea: build a premise and arc from scratch.
- Existing outline/script: diagnose structural weaknesses and propose repairs.
- Vague request: default to a reusable female-oriented short-drama framework, but label it as a default rather than a fact.

Define whether the user needs a hook, premise, character engine, episode grid, season arc, rewrite diagnosis, or a full development package.

### 2. Extract the story engine

Write one line for each field:

1. **Visible goal**: what the protagonist is trying to obtain, protect, escape, expose, or change.
2. **Hidden need**: the emotional or identity need beneath the visible goal.
3. **Initial disadvantage**: the status, rule, relationship, injury, debt, accusation, or deadline that puts the protagonist low.
4. **Opposition**: the person, institution, family, system, or internal contradiction that blocks the goal.
5. **Information gap**: what the audience, protagonist, ally, and antagonist each know or misread.
6. **Unique promise**: the repeatable pleasure the story promises, such as strategic revenge, identity reveals, romantic tension, courtroom reversals, or public recognition.

Form the high-concept hook as:

> An abnormal identity or ability enters an extreme situation and must make an irreversible choice before a specific loss occurs.

Keep the hook concrete. “She wants a better life” is too broad; “Before the ancestral trial at sunset, the disowned daughter must prove the crime was framed” is usable.

### 3. Build the season or long-arc spine

Use this general progression, adapting the number of episodes to the platform:

1. **Cold open**: show the abnormal situation, the immediate danger, and the promise of reversal.
2. **Low position**: make the loss or humiliation legible; let the audience know what is unfair.
3. **Agency**: make the protagonist choose a concrete goal and take the first active step.
4. **Progressive wins**: deliver small, varied reversals that prove competence while creating new complications.
5. **Midpoint turn**: reveal a larger truth, change the target, or force the protagonist from survival into active contest.
6. **Counterattack and cost**: let the opposition attack a real weakness; winning must no longer be free.
7. **Lowest point**: remove the apparent advantage or break a key relationship, while preserving a planted possibility.
8. **Public climax**: make the protagonist use the earlier setup to reverse the power order in front of witnesses.
9. **Emotional resolution and next hook**: fulfil or redefine the hidden need, show the consequence, and open the next larger question.

Do not make every escalation a stronger fight. Vary the axis: private to public, personal to institutional, reputation to survival, and survival to identity or values.

### 4. Design each episode

Use the compact loop:

> New problem -> pressure or misdirection -> protagonist chooses -> power shifts -> payoff -> new question.

Require each episode to contain:

- one primary conflict rather than several unrelated events;
- one active protagonist decision;
- one visible change in who has leverage;
- one quotable action, line, reveal, or image;
- one ending hook that changes what the next episode is about.

For a short episode, allocate roughly:

- opening: 10% for the hook;
- development: 50-60% for pressure and escalating obstacles;
- climax: 20-30% for the reversal and payoff;
- ending: 10% for emotional aftertaste and the next question.

### 5. Write the corresponding script

Translate the approved structure into an executable screenplay instead of a prose synopsis:

1. Convert each episode beat into a scene list. Every scene needs an objective, an obstacle, a turn, and an exit effect on the next scene.
2. Use clear scene headers such as `第1集｜场1｜内·沈府偏厅·夜` and separate action, character names, dialogue, and essential sound or visual cues.
3. Make the protagonist choose or cause the turn whenever the beat sheet assigns her agency. Do not let exposition, an ally, or an unexplained ability solve the conflict for her.
4. Write playable actions and speakable dialogue. Give each major character a distinct tactic, rhythm, and concealed intention; avoid using narration to replace conflict.
5. Preserve planted clues, information gaps, reversals, emotional payoffs, and the episode hook from the structure. If a script change breaks the structure, update the structure and flag the change.
6. End every requested episode with a concrete new question, danger, decision, or reveal. A scene-ending line alone is not a hook unless it changes what follows.
7. For every episode, verify the default or user-specified character range, 6–10-scene range, runtime estimate, and five mandatory content items. Treat the key-episode expansion as an exception, not the standard.

When a user asks for a full script but the requested scope exceeds one response, deliver a coherent first batch with an exact stopping point and a compact continuity ledger for the next batch. Never label a synopsis or beat sheet as a completed screenplay.

### 6. Engineer the emotional experience

Track three gaps in every major beat:

- **Information gap**: who knows the truth?
- **Power gap**: who appears to control the situation, and who actually does?
- **Emotion gap**: what injustice or longing is the audience carrying toward the payoff?

Move the audience through:

> suppression or anger -> anticipation -> reversal -> catharsis -> sweetness or tears -> curiosity.

Make the emotional payoff answer the hidden need, not merely announce that the protagonist won.

### 7. Adapt for female-oriented ancient drama

Give the heroine three explicit anchors:

- a visible objective;
- a hidden emotional need;
- a non-negotiable boundary.

Use ancient institutions as active pressure systems: marriage and lineage, clan rules, court hierarchy, inheritance, reputation, ritual, law, war, or succession. Put major payoffs in public arenas such as a wedding, court, ancestral hall, palace audience, examination, military camp, or succession ceremony so the reversal becomes socially irreversible.

Build relationships as choices and costs. The male lead, rival, family, and allies should each create a different decision for the heroine; do not let every relationship become a passive rescue device.

### 8. Diagnose and revise

Check the draft against these questions:

- Is the premise explainable in one sentence?
- Does the first scene contain a contradiction, danger, or urgent choice?
- Does the heroine act, rather than only react?
- Does each victory change the situation instead of repeating the same humiliation?
- Does the opposition learn, adapt, and make the cost real?
- Are major reversals planted before they are revealed?
- Is the climax public, specific, and irreversible?
- Does the ending satisfy both the visible goal and the hidden need?

Flag these risks explicitly:

- repeated face-slaps with no new stakes;
- a sudden omnipotent solution with no setup;
- a passive heroine carried by allies;
- a one-note antagonist who only insults;
- unlimited money, status, or coincidence removing all danger;
- romance that has attraction but no meaningful choice;
- identity reveals that replace rather than deepen the protagonist's agency;
- a cliffhanger that adds noise but no new question.

## Output format

When analyzing or developing a story, use this order unless the user asks for another format:

1. **Core judgment**: one paragraph naming the real structural engine.
2. **Surface vs. mechanism**: distinguish what is genre-specific from what can be reused.
3. **High-concept hook**: one sentence plus the visible goal, hidden need, and initial disadvantage.
4. **Story bible**: protagonist, opposition, allies, relationships, rules, secrets, and character choices.
5. **Long-arc map**: cold open, low point, agency, escalation, midpoint, counterattack, lowest point, climax, resolution.
6. **Episode engine**: the repeated loop and a sample episode grid if requested.
7. **Escalation plan**: show how conflict rises in scope, cost, and public visibility.
8. **Emotional line**: state what the audience feels and what relationship or value is paid off.
9. **Corresponding script**: write the requested scenes or episodes in screenplay format; include the endpoint if the script is batched.
10. **Risks and repairs**: name specific weaknesses and actionable changes.
11. **Reusable formula**: end with a short, genre-neutral formula the user can apply elsewhere.

End the final deliverable with the brand watermark exactly once.

For reference-script analysis, cite episode or scene evidence when available, but do not over-quote. Explain why each device works and how to transplant the mechanism into a different premise.

## Reference

Read [references/structure-framework.md](references/structure-framework.md) when detailed hook formulas, reversal tests, escalation ladders, or female-ancient scene applications are needed. Read [references/script-writing-framework.md](references/script-writing-framework.md) when converting the structure into scenes, dialogue, episode scripts, or a continuation batch.
