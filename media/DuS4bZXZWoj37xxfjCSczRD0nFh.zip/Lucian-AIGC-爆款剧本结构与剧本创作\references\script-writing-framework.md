# Script Writing Framework

Use this reference when the user wants the approved viral structure turned into a playable script, a complete episode, a continuation batch, or a rewrite.

## 1. Script contract

The structure is the source of truth, but the script is the deliverable. Map each major beat to one or more scenes and preserve:

- the protagonist's visible goal, hidden need, and boundary;
- the information, power, and emotion gaps;
- planted clues before reveals;
- the cost of each victory;
- the public or private payoff promised by the arc;
- the final decision, danger, or question that drives the next episode.

Do not replace scenes with a story summary. If the user requests only an outline, do not invent a full script; if the user requests a script, include playable action and dialogue.

## 2. Default production envelope

When the user has not specified the episode count or production length, use this envelope:

- 20–25 episodes per season;
- approximately 40,000–50,000 Chinese characters of screenplay正文 for the season;
- 1,500–2,200 Chinese characters, 6–10 scenes, and about 3–5 minutes per standard episode;
- 2,500–3,200 Chinese characters only for a key episode that needs a major turn, reversal, lowest point, or climax.

Every episode must contain all five items: an opening hook, a reality conflict, one concrete cathartic payoff, one relationship progression, and an ending hook. Count the episode after drafting and revise scenes that do not change information, leverage, emotion, or the next action. User-provided specifications override these defaults.

## 3. Scene card

Before drafting a scene, fill this compact card:

```text
Scene: [episode and scene number]
Location/time: [inside or outside, place, day or night]
Scene purpose: [which structural beat this pays or plants]
Protagonist objective: [what she wants now]
Opposition: [who or what blocks it]
Tactic: [what the protagonist tries]
Turn: [what new fact, choice, or action changes leverage]
Exit state: [what is now different]
Hook: [what question or danger pulls us onward]
```

If a scene has no objective, opposition, or changed exit state, merge it, cut it, or give it a new dramatic function.

## 4. Chinese short-drama screenplay format

Use a compact, readable format unless the user requests another industry format:

```text
《剧名》
第1集

场1｜内·沈府偏厅·夜

人物：沈昭、顾临川、沈夫人

【动作】沈昭将染血的玉佩放在案上，屋内立刻安静。

沈夫人
你还敢回来？

沈昭（看向门外）
我若不回来，今晚死的就不是一个人。

【音效】门外传来急促脚步。

【本集钩子】门被推开，来人喊出沈昭从未公开过的旧名。
```

Scene headers must make production space and time clear. Action should be visible or audible. Keep parentheticals short and use them only when they change performance meaning.

## 5. Dialogue rules

Use dialogue to pursue, evade, bargain, threaten, test, or reveal—not to recite the plot. For every important exchange:

1. give each side a different immediate objective;
2. let the speaker conceal at least one important intention;
3. make the power shift visible in the reply, interruption, silence, object, or action;
4. end on a decision, image, reveal, or unanswered threat.

Avoid giving every character the same clever voice. The heroine can be restrained, sharp, warm, deceptive, or explosive, but her wording should match her strategy and current leverage.

## 6. Episode conversion

For each short episode, translate the beat loop into scenes:

1. **Opening hook**: an abnormal image, accusation, imminent loss, or impossible choice.
2. **Pressure**: the opposition makes the obvious response costly.
3. **Choice**: the protagonist takes an active, character-revealing action.
4. **Turn**: the apparent power order changes through action or information.
5. **Payoff**: deliver a concrete emotional or strategic reward.
6. **Next question**: make the victory create a new problem, target, or cost.

Do not repeat the same public humiliation and face-slap pattern. Vary the scene arena, the type of leverage, the emotional price, and the kind of reveal.

## 7. Continuation ledger

When drafting in batches, carry forward a short ledger:

- unresolved questions and promised reveals;
- current goals and leverage for every major character;
- secrets known by the audience, heroine, ally, and antagonist;
- objects, injuries, vows, debts, evidence, and time limits in play;
- relationships changed in the last batch;
- the exact next scene or hook to resume from.

Never invent a new fact in a continuation that silently contradicts this ledger. If a repair is necessary, flag it and update the story bible.

## 8. Script quality check

Before delivery, verify:

- the opening can be understood without backstory exposition;
- the heroine causes meaningful turns;
- every scene changes information, power, emotion, or all three;
- dialogue is speakable and character-specific;
- reveals have earlier plants;
- the climax pays a promise from the structure;
- episode endings create a new question rather than only stopping;
- the script can be filmed from the written actions and locations;
- the episode meets its character, scene, runtime, and five-item content requirements;
- the script scope is labeled honestly as complete, excerpted, or batched.
