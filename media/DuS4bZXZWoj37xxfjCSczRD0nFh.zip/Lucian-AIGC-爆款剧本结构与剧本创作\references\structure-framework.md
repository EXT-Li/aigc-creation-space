# Reusable Structure Framework

Use this reference when the task needs more than the core workflow in `SKILL.md`.

## Contents

1. High-concept formulas
2. Reversal design
3. Escalation ladder
4. Episode beat sheet
5. Female-oriented ancient-drama applications
6. Surface trope versus transferable mechanism

## 1. High-concept formulas

Replace the bracketed fields with story-specific material. Keep the sentence concrete and time-bound.

- **Forced transformation**: The person least suited to `[role]` must become `[role]` before `[deadline]`, or `[loss]` occurs.
- **Reclamation**: After `[identity/status/relationship]` is taken, `[protagonist]` must recover it through `[public test or dangerous mission]`.
- **Information asymmetry**: Everyone believes `[false story]`; only `[protagonist or audience]` knows `[hidden truth]`, but proving it requires `[cost]`.
- **Trap with agency**: To escape `[constraint]`, the protagonist must accept `[worse-looking choice]`, which puts her in direct conflict with `[opposition]`.
- **Relationship contradiction**: The person the protagonist must defeat is also the person she cannot stop protecting, forcing a choice between `[value A]` and `[value B]`.
- **Institutional reversal**: A rule created to exclude the protagonist becomes the mechanism through which she can publicly overturn the people who made it.

Reject hooks that only name a category: “a rebirth revenge story” or “a sweet palace romance.” Add the abnormal condition, immediate pressure, concrete objective, and deadline.

## 2. Reversal design

A satisfying reversal has four parts:

1. **Plant**: establish a skill, object, relationship, rule, contradiction, or line that can later matter.
2. **Misdirect**: let characters interpret the plant in a plausible but incomplete way.
3. **Reveal**: show the plant's real function at the moment the protagonist must act.
4. **Consequence**: change the power relationship, reputation, relationship, or available choices.

Classify the reversal before writing it:

- **Capability reversal**: the apparently weak character has a specific competence.
- **Identity reversal**: the public identity is false, incomplete, or politically useful.
- **Motive reversal**: a hostile or romantic action has a different reason.
- **Rule reversal**: a rule can be turned against the person who invoked it.
- **Alliance reversal**: the expected ally, enemy, or relationship changes sides or meaning.
- **Value reversal**: what looked like a loss becomes the protagonist's chosen freedom.

Do not stack reveals merely to surprise. Each reveal must change what the protagonist can do next.

## 3. Escalation ladder

Increase at least two of the following at each major turn:

| Level | Main question | Typical arena |
|---|---|---|
| Personal | Can she protect herself or keep a promise? | room, home, private meeting |
| Relational | Who will believe, betray, or choose her? | family, marriage, alliance |
| Social | Can she reverse public judgment? | banquet, trial, examination |
| Institutional | Can she change the rule or defeat its owner? | clan, court, army, temple |
| Existential | What identity, value, or future will she choose? | succession, war, sacrifice, final revelation |

Escalation is not only stronger enemies. Rotate the pressure among:

- time: a deadline becomes shorter;
- visibility: more witnesses see the conflict;
- cost: victory demands a sacrifice;
- complexity: two valid goals conflict;
- reversibility: an action can no longer be undone;
- emotional exposure: the protagonist must say or choose what she has avoided.

## 4. Episode beat sheet

Use this five-beat template for a short episode. Compress or expand it according to runtime.

### Beat 1: Hook

Open on a contradiction, an insult, an urgent request, a dangerous discovery, or a choice already in motion. Do not spend the opening on background exposition.

### Beat 2: Pressure

Let the opposing force make the protagonist's obvious solution unavailable. Show the rule, threat, witness, deadline, or misunderstanding that raises the cost.

### Beat 3: Choice

Make the protagonist act. A refusal, bargain, lie, public statement, alliance, sacrifice, or strategic concession is stronger than a passive reaction.

### Beat 4: Reversal and payoff

Use the planted mechanism to change leverage. Make the payoff specific and visible: a verdict changes, a rival loses authority, a relationship is redefined, or a public audience must revise its judgment.

### Beat 5: New question

End with a consequence, new threat, hidden witness, unresolved relationship, or changed goal. A hook should make the next episode necessary, not merely possible.

## 5. Female-oriented ancient-drama applications

### Heroine design

Define:

- **Want**: the immediate objective she can pursue on screen.
- **Need**: the emotional truth she must accept or reclaim.
- **Boundary**: the humiliation, betrayal, or compromise she will no longer tolerate.
- **Leverage**: the knowledge, skill, status, evidence, relationship, or moral authority she can use.
- **Cost**: what she risks losing each time she uses that leverage.

Avoid making the heroine's only goal “prove she is not weak.” Give her something external and measurable to win.

### Ancient pressure systems

Turn worldbuilding into conflict rather than decoration:

- marriage and lineage create a deadline or ownership dispute;
- clan law turns a private accusation into a public trial;
- court rank controls who may speak and whose evidence counts;
- ritual or examination creates a stage for public reversal;
- inheritance, military command, or succession makes personal conflict political;
- reputation determines whether a victory can be enjoyed or must be hidden.

### Relationship architecture

Give each major relationship a different dramatic function:

- the rival tests the heroine's boundary;
- the ally offers help with a price;
- the romantic lead creates a choice, not only protection;
- the family embodies history, obligation, or emotional refuge;
- the authority figure controls the rule the heroine must overturn.

At least one relationship should worsen because of the heroine's success. This prevents the emotional line from becoming consequence-free praise.

## 6. Surface trope versus transferable mechanism

| Surface trope | Transferable mechanism |
|---|---|
| Rebirth | A new perspective enters an old power structure and can reinterpret its rules. |
| Hidden identity | Information asymmetry creates suspense and delays public recognition. |
| Revenge | A concrete wound creates a sequence of targets and escalating costs. |
| Contract marriage | A forced alliance turns intimacy into negotiation and later choice. |
| Palace intrigue | Institutions distribute power unevenly and make witnesses consequential. |
| Powerful family | A support network externalizes love, resources, obligations, and conflict. |
| “Trash” or weak heroine | A low public position makes each change in status legible and satisfying. |
| Genius heroine | Competence creates repeatable problem-solving pleasure, but must meet real tradeoffs. |
| Misunderstanding comedy | An information gap creates simultaneous audience knowledge and character error. |
| Public face-slap | A private advantage becomes socially undeniable in front of the people who judged her. |

When adapting a reference, keep the mechanism and replace at least three surface elements: protagonist goal, opposition system, relationship configuration, setting arena, and type of payoff.

## Final quality test

Before delivering an outline or diagnosis, verify:

- The hook contains a specific contradiction and deadline.
- The protagonist makes an active choice early.
- The opposition has a strategy and can learn from setbacks.
- Every major reversal is planted and changes the next choice.
- Stakes escalate in scope, cost, or public visibility.
- The climax solves the story's central injustice or desire.
- The emotional ending answers the hidden need.
- The structure remains valid if the reference story's names, powers, family, jokes, and worldbuilding are removed.
